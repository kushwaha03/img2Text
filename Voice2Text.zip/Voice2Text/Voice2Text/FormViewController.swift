//
//  FormViewController.swift
//  Voice2Text
//
//  Created by Krishna Kushwaha on 02/09/22.
//

import UIKit
import Speech
class FormViewController: UIViewController {

    // MARK:- textField
    //------------------------------------------------------------------------------
    @IBOutlet weak var firstTxt: UITextField!
    @IBOutlet weak var midxt: UITextField!
    @IBOutlet weak var lastTxt: UITextField!
    @IBOutlet weak var mailTxt: UITextField!
    @IBOutlet weak var mobTxt: UITextField!

    @IBOutlet weak var micBtn: UIButton!
    @IBOutlet weak var micBtn1: UIButton!
    @IBOutlet weak var micBtn2: UIButton!
    @IBOutlet weak var micBtn3: UIButton!
    @IBOutlet weak var micBtn4: UIButton!
    @IBOutlet weak var txtView: UITextView!
    
    @IBOutlet weak var micBtn5: UIButton!
    // MARK:- speech

    let speechRecognizer        = SFSpeechRecognizer(locale: Locale(identifier: "en-US"))
    var recognitionRequest      : SFSpeechAudioBufferRecognitionRequest?
    var recognitionTask         : SFSpeechRecognitionTask?
    let audioEngine             = AVAudioEngine()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setupSpeech()
        //Looks for single or multiple taps.
            let tap = UITapGestureRecognizer(target: self, action: #selector(UIInputViewController.dismissKeyboard))

           //Uncomment the line below if you want the tap not not interfere and cancel other interactions.
           //tap.cancelsTouchesInView = false

           view.addGestureRecognizer(tap)

    }
    @objc  func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)

    }
    func startRecording1() {

        // Clear all previous session data and cancel task
        if recognitionTask != nil {
            recognitionTask?.cancel()
            recognitionTask = nil
        }

        // Create instance of audio session to record voice
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(AVAudioSession.Category.record, mode: AVAudioSession.Mode.measurement, options: AVAudioSession.CategoryOptions.defaultToSpeaker)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            print("audioSession properties weren't set because of an error.")
        }

        self.recognitionRequest = SFSpeechAudioBufferRecognitionRequest()

        let inputNode = audioEngine.inputNode

        guard let recognitionRequest = recognitionRequest else {
            fatalError("Unable to create an SFSpeechAudioBufferRecognitionRequest object")
        }

        recognitionRequest.shouldReportPartialResults = true

        self.recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest, resultHandler: { (result, error) in

            var isFinal = false

            if result != nil {

//                self.lblText.text = result?.bestTranscription.formattedString
//                self.txtField.text = result?.bestTranscription.formattedString
//                self.txtView.text = result?.bestTranscription.formattedString
                isFinal = (result?.isFinal)!
            }

            if error != nil || isFinal {

                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)

                self.recognitionRequest = nil
                self.recognitionTask = nil

                self.micBtn.isEnabled = true
                self.micBtn1.isEnabled = true
                self.micBtn2.isEnabled = true
                self.micBtn3.isEnabled = true
                self.micBtn4.isEnabled = true

            }
        })

        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, when) in
            self.recognitionRequest?.append(buffer)
        }

        self.audioEngine.prepare()

        do {
            try self.audioEngine.start()
        } catch {
            print("audioEngine couldn't start because of an error.")
        }

//        self.lblText.text = "Say something, I'm listening!"
    }
    @IBAction func mic1Ac(_ sender: UIButton) {
        print("tag:", sender.tag)

        if sender.tag == 0 {
            if audioEngine.isRunning {
                self.audioEngine.stop()
                self.recognitionRequest?.endAudio()
                self.micBtn.isEnabled = false
                self.micBtn.setImage(UIImage(named: "mic.png"), for: .normal)
            } else {
                self.startRecording( tag: 0)
                self.micBtn.setImage(UIImage(named: "unmic.png"), for: .normal)

            }
        } else if sender.tag == 1 {
            if audioEngine.isRunning {
                self.audioEngine.stop()
                self.recognitionRequest?.endAudio()
                self.micBtn1.isEnabled = false
                self.micBtn1.setImage(UIImage(named: "mic.png"), for: .normal)
            } else {
                self.startRecording( tag: 1)
                self.micBtn1.setImage(UIImage(named: "unmic.png"), for: .normal)

            }
        }  else if sender.tag == 2 {
            if audioEngine.isRunning {
                self.audioEngine.stop()
                self.recognitionRequest?.endAudio()
                self.micBtn2.isEnabled = false
                self.micBtn2.setImage(UIImage(named: "mic.png"), for: .normal)
            } else {
                self.startRecording( tag: 2)
                self.micBtn2.setImage(UIImage(named: "unmic.png"), for: .normal)

            }
        }

        else if sender.tag == 3 {
           if audioEngine.isRunning {
               self.audioEngine.stop()
               self.recognitionRequest?.endAudio()
               self.micBtn3.isEnabled = false
               self.micBtn3.setImage(UIImage(named: "mic.png"), for: .normal)
           } else {
               self.startRecording( tag: 3)
               self.micBtn3.setImage(UIImage(named: "unmic.png"), for: .normal)

           }
       }

        else if sender.tag == 4 {
           if audioEngine.isRunning {
               self.audioEngine.stop()
               self.recognitionRequest?.endAudio()
               self.micBtn4.isEnabled = false
               self.micBtn4.setImage(UIImage(named: "mic.png"), for: .normal)
           } else {
               self.startRecording( tag: 4)
               self.micBtn4.setImage(UIImage(named: "unmic.png"), for: .normal)

           }
        } else {
            if audioEngine.isRunning {
                self.audioEngine.stop()
                self.recognitionRequest?.endAudio()
                self.micBtn5.isEnabled = false
                self.micBtn5.setImage(UIImage(named: "mic.png"), for: .normal)
            } else {
                self.startRecording( tag: 5)
                self.micBtn5.setImage(UIImage(named: "unmic.png"), for: .normal)

            }
        }


       
    }
    func setupSpeech() {

        self.micBtn.isEnabled = false
        self.micBtn1.isEnabled = false
        self.micBtn2.isEnabled = false
        self.micBtn3.isEnabled = false
        self.micBtn4.isEnabled = false

        self.speechRecognizer?.delegate = self

        SFSpeechRecognizer.requestAuthorization { (authStatus) in

            var isButtonEnabled = false

            switch authStatus {
            case .authorized:
                isButtonEnabled = true

            case .denied:
                isButtonEnabled = false
                print("User denied access to speech recognition")

            case .restricted:
                isButtonEnabled = false
                print("Speech recognition restricted on this device")

            case .notDetermined:
                isButtonEnabled = false
                print("Speech recognition not yet authorized")
            }

            OperationQueue.main.addOperation() {
                self.micBtn.isEnabled = isButtonEnabled
                self.micBtn1.isEnabled = isButtonEnabled
                self.micBtn2.isEnabled = isButtonEnabled
                self.micBtn3.isEnabled = isButtonEnabled
                self.micBtn4.isEnabled = isButtonEnabled

            }
        }
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
extension FormViewController: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
    
//        if textField.tag == 0 {
//            print("yes tell me")
//        } else if textField.tag == 1 {
//            self.startRecording( tag: textField.tag)
//            print("yes tell me1")
//        } else  if textField.tag == 2 {
//            self.startRecording( tag: textField.tag)
//
//            print("yes tell me2")
//        } else if textField.tag == 3 {
//            self.startRecording( tag: textField.tag)
//
//            print("yes tell m3")
//        } else if textField.tag == 4 {
//            self.startRecording( tag: textField.tag)
//
//            print("yes tell me4")
//        }

    }
//    func textFieldDidEndEditing(_ textField: UITextField) {
//        print("yes tell me1")
//
//    }

    
    func startRecording(tag: Int) {

        // Clear all previous session data and cancel task
        if recognitionTask != nil {
            recognitionTask?.cancel()
            recognitionTask = nil
        }

        // Create instance of audio session to record voice
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.setCategory(AVAudioSession.Category.record, mode: AVAudioSession.Mode.measurement, options: AVAudioSession.CategoryOptions.defaultToSpeaker)
            try audioSession.setActive(true, options: .notifyOthersOnDeactivation)
        } catch {
            print("audioSession properties weren't set because of an error.")
        }

        self.recognitionRequest = SFSpeechAudioBufferRecognitionRequest()

        let inputNode = audioEngine.inputNode

        guard let recognitionRequest = recognitionRequest else {
            fatalError("Unable to create an SFSpeechAudioBufferRecognitionRequest object")
        }
        recognitionRequest.shouldReportPartialResults = true

        self.recognitionTask = speechRecognizer?.recognitionTask(with: recognitionRequest, resultHandler: { (result, error) in

            var isFinal = false

            if result != nil {
                if tag == 0 {
                self.firstTxt.text = result?.bestTranscription.formattedString
                } else if tag == 1 {
                    self.midxt.text = result?.bestTranscription.formattedString
                } else if tag == 2 {
                    self.lastTxt.text = result?.bestTranscription.formattedString
                } else if tag == 3 {
                    self.mailTxt.text = result?.bestTranscription.formattedString
                } else if tag == 4 {
                    self.mobTxt.text = result?.bestTranscription.formattedString

                } else {
                    
                    self.txtView.text = result?.bestTranscription.formattedString
                }
             
                isFinal = (result?.isFinal)!
            }

            if error != nil || isFinal {

                self.audioEngine.stop()
                inputNode.removeTap(onBus: 0)

                self.recognitionRequest = nil
                self.recognitionTask = nil

                self.micBtn.isEnabled = true
                self.micBtn1.isEnabled = true
                self.micBtn2.isEnabled = true
                self.micBtn3.isEnabled = true
                self.micBtn4.isEnabled = true

            }
        })

        let recordingFormat = inputNode.outputFormat(forBus: 0)
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, when) in
            self.recognitionRequest?.append(buffer)
        }

        self.audioEngine.prepare()

        do {
            try self.audioEngine.start()
        } catch {
            print("audioEngine couldn't start because of an error.")
        }

//        self.firstTxt.text = "Say something, I'm listening!"
    }
}
extension FormViewController: SFSpeechRecognizerDelegate {

    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        if available {
            self.micBtn.isEnabled = true
            self.micBtn1.isEnabled = true
            self.micBtn2.isEnabled = true
            self.micBtn3.isEnabled = true
            self.micBtn4.isEnabled = true

        } else {
            self.micBtn.isEnabled = false
            self.micBtn1.isEnabled = false
            self.micBtn2.isEnabled = false
            self.micBtn3.isEnabled = false
            self.micBtn4.isEnabled = false

        }
    }
}
extension UIView {
    @IBInspectable var cornerRadius: CGFloat {
        set {
            layer.cornerRadius = newValue
            layer.masksToBounds = newValue > 0
        }
        get {
            return layer.cornerRadius
        }
    }
    @IBInspectable var borderColor: UIColor? {
        get {
              if let cgcolor = layer.borderColor {
                  return UIColor(cgColor: cgcolor)
              } else {
                return nil
              }
            }
            set {
                layer.borderColor = newValue?.cgColor

              // width must be at least 1.0
              if layer.borderWidth < 1.0 {
                layer.borderWidth = 1.0
              }
            }
       }

       @IBInspectable var borderWidth: CGFloat {
           set {
               layer.borderWidth = newValue
               layer.masksToBounds = newValue > 0
           }
           get {
               return layer.borderWidth
           }
       }
}
//extension UIViewController {
//    func hideKeyboardWhenTappedAround() {
//        let tap = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
//        tap.cancelsTouchesInView = false
//        view.addGestureRecognizer(tap)
//    }
//
//    @objc func dismissKeyboard() {
//        view.endEditing(true)
//    }
//}
